// Empty geo script
UNUSED static const u64 cannon_lid_unused_1 = 0;
