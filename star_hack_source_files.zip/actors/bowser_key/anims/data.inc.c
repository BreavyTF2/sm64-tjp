#include "anim_course_exit.inc.c"
#include "anim_unlock_door.inc.c"
