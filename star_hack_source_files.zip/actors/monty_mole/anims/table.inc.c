// 0x05007248
const struct Animation *const monty_mole_seg5_anims_05007248[] = {
    &monty_mole_seg5_anim_05004FEC,
    &monty_mole_seg5_anim_0500527C,
    &monty_mole_seg5_anim_050054B0,
    &monty_mole_seg5_anim_050062B0,
    &monty_mole_seg5_anim_050065C0,
    &monty_mole_seg5_anim_05006880,
    &monty_mole_seg5_anim_05006B10,
    &monty_mole_seg5_anim_05006DB8,
    &monty_mole_seg5_anim_05007230,
    &monty_mole_seg5_anim_050065D8,
    NULL,
    NULL,
};
