// 0x06015634
const struct Animation *const mips_seg6_anims_06015634[] = {
    &mips_seg6_anim_06014B94,
    &mips_seg6_anim_060139F8,
    &mips_seg6_anim_06013248,
    &mips_seg6_anim_0601561C,
    &mips_seg6_anim_0601369C,
    NULL,
    NULL,
};
