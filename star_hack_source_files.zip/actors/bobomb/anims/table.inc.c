// 0x0802396C
const struct Animation *const bobomb_seg8_anims_0802396C[] = {
    &bobomb_seg8_anim_080237FC,
    &bobomb_seg8_anim_08023954,
    NULL,
};
