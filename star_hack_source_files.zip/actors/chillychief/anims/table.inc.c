// 0x06003994
const struct Animation *const chilly_chief_seg6_anims_06003994[] = {
    &chilly_chief_seg6_anim_060035E0,
    &chilly_chief_seg6_anim_06003420,
    &chilly_chief_seg6_anim_060032EC,
    &chilly_chief_seg6_anim_0600373C,
    NULL,
};
