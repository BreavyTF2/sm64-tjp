// 0x0500F3F0
static const struct Animation eyerok_seg5_anim_0500F3F0 = {
    35,
    0,
    29,
    0,
    0x1E,
    ANIMINDEX_NUMPARTS(eyerok_seg5_animindex_0500F1D4),
    eyerok_seg5_animvalue_0500E9B4,
    eyerok_seg5_animindex_0500F1D4,
    0,
};
