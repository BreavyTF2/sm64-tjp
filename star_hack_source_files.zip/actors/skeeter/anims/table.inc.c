// 0x06007DE0
const struct Animation *const skeeter_seg6_anims_06007DE0[] = {
    &skeeter_seg6_anim_06005D44,
    &skeeter_seg6_anim_06006B70,
    &skeeter_seg6_anim_060071E0,
    &skeeter_seg6_anim_06007DC8,
};
