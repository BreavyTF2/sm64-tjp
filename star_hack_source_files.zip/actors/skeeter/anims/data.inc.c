#include "anim_06005D44.inc.c"
#include "anim_06006B70.inc.c"
#include "anim_060071E0.inc.c"
#include "anim_06007DC8.inc.c"
