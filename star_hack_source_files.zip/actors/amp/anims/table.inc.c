// 0x08004034
const struct Animation *const amp_seg8_anims_08004034[] = {
    &amp_seg8_anim_0800401C,
};
